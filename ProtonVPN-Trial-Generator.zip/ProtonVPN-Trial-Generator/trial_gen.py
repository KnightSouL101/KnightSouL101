# ###########################
# ProtonVPN trail Generator
# ###########################

from selenium import webdriver
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import csv
import string
import random
import time
import sys
import os
import requests
import platform
import warnings
from selenium.webdriver.common.keys import Keys


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

driver_path = "default"
clear_cmd = "clear"

os_name = platform.system()

if os_name == 'Linux':
    driver_path = 'chromedriver'
elif os_name == 'Windows':
    driver_path = 'chromedriver.exe'
    clear_cmd = 'cls'
else:
    driver_path = 'chromedrivermac'

def clear():
    return os.system(clear_cmd)

clear()

use_proxy = True
proxy_scrape = True

ask_use_question = True
ask_scrape_question = True

while ask_use_question == True:
    clear()
    proxyuse_answer = input('\n\nWould you like to use proxy?[y/n]\n').lower()
    if proxyuse_answer == 'y':
        use_proxy = True
        ask_use_question = False
    elif proxyuse_answer == 'n':
        ask_use_question = False
        use_proxy = False
    else:
        ask_use_question = True

if use_proxy == True:
    while ask_scrape_question == True:
        clear()
        proxy_answer = input('\n\nWould you like to scrape proxy?[y/n]\n').lower()
        if proxy_answer == 'y':
            ask_scrape_question = False
            proxy_scrape = True
        elif proxy_answer == 'n':
            ask_scrape_question = False
            proxy_scrape = False
        else:
            ask_scrape_question = True
else:
    ask_scrape_question = False
    proxy_scrape = False


proxy_no = 1
email = ''


def create_proxies():
    # ######################################################
    # Python script to generate proxies from 'hidemy.name'
    # ######################################################
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    import csv

    global use_proxy
    global proxy_scrape
    global driver_path

    if proxy_scrape == True:
        clear()

        global proxy_no

        proxy_no = 1

        print('\n\n Please wait while we scrape for proxies... \n\n')

        # ###################
        # Clearing CSV file
        # ###################

        filename = "proxies.csv"
        # opening the file with w+ mode truncates the file
        f = open(filename, "w+")
        f.close()

        # ###############
        # Selenium code
        # ###############

        driver = webdriver.Chrome(executable_path = driver_path)

        driver.get('https://hidemy.name/en/proxy-list/?maxtime=500#list')

        proxy_table = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'proxy__t')))

        proxy_rows = proxy_table.find_elements_by_tag_name('tr')

        proxy_csv_total = []
        proxy_csv_one = []

        for proxy_row in proxy_rows:
            proxy_cols = proxy_row.find_elements_by_tag_name('td')
            if proxy_csv_one != []:
                proxy_csv_total.append(proxy_csv_one[:2])
            proxy_csv_one = []
            for proxy_col in proxy_cols:
                proxy_csv_one.append(proxy_col.text)

        driver.close()

        # ##########################
        # Writing proxies into CSV
        # ##########################

        with open('proxies.csv', 'a', newline='') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerows(proxy_csv_total)
        csvFile.close()
        print('\n\nGreat! Proxies were added to the csv file\n\n')

    global email
    if email == '':
        create_email()
    else:
        create_account()


def create_email():

    # ###########################################
    # Script to get temp email from tempmail.io
    # ###########################################

    clear()

    global driver_path
    global email
    global use_proxy
    global proxy_scrape

    print('\n\n Generating temp mail \n\n')

    driver = webdriver.Chrome(executable_path = driver_path)

    driver.get('https://temp-mail.io/en')

    change_email = WebDriverWait(driver, 60).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[title="Change email to the new one"]')))
    change_email.click()

    def randomStringDigits(stringLength=13):
        # Generate a random string of letters and digits
        letters = string.ascii_letters
        return ''.join(random.choice(letters) for i in range(stringLength))

    username_email = randomStringDigits(6).lower()

    time.sleep(1.5)

    username_input = WebDriverWait(driver, 60).until(
        EC.presence_of_element_located((By.ID, 'name')))
    username_input.send_keys(username_email)

    domain_selector = WebDriverWait(driver, 60).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, 'select[name="domain"] option[value="5"]')))
    domain_selector.click()

    time.sleep(1)

    change_button = WebDriverWait(driver, 60).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[class="btn btn-default btn_block"]')))
    change_button.click()

    time.sleep(1)

    input_email = WebDriverWait(driver, 60).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, 'span[class="email__input email__input_clone"]')))
    email = input_email.get_attribute('innerHTML')

    print(email)

    create_account()


def create_account():

    # ################################
    # Script to create trail account
    # ################################

    clear()

    print(r'''



   ___           _                    ___    __  
  / _ \_ __ ___ | |_ ___  _ __/\   /\/ _ \/\ \ \ 
 / /_)/ '__/ _ \| __/ _ \| '_ \ \ / / /_)/  \/ / 
/ ___/| | | (_) | || (_) | | | \ V / ___/ /\  /  
\/    |_|  \___/ \__\___/|_| |_|\_/\/   \_\ \/   
                                                 
 _        _       _                              
| |_ _ __(_) __ _| |                             
| __| '__| |/ _` | |                             
| |_| |  | | (_| | |                             
 \__|_|  |_|\__,_|_|                             
                                                 
                                 _               
  __ _  ___ _ __   ___ _ __ __ _| |_ ___  _ __   
 / _` |/ _ \ '_ \ / _ \ '__/ _` | __/ _ \| '__|  
| (_| |  __/ | | |  __/ | | (_| | || (_) | |     
 \__, |\___|_| |_|\___|_|  \__,_|\__\___/|_|     
 |___/                                           




    ''')

    global email
    global use_proxy
    global proxy_scrape
    global driver_path
    global proxy_no

    if email == '':
        email = input("Please enter email: \t")

    print('\n\n\n')

    # ###########
    # Use proxy
    # ###########

    if use_proxy == True:

        proxy_on = False

        while proxy_on == False:
            if proxy_no > 62:
                print("\n\n Rescraping proxies \n\n")
                create_proxies()

            with open('proxies.csv') as csvfile:
                reader = csv.reader(csvfile)
                proxie_rows = []
                for row in reader:
                    proxie_rows.append(row)
                proxy_to_use = proxie_rows[proxy_no]
                proxy_host = proxy_to_use[0]
                proxy_port = proxy_to_use[1]

            proxy_auth = ":"

            try:
                proxy = ("{}:{}".format(proxy_host, proxy_port))
                print('\033[31m' + "Proxy:", proxy + '\033[0m')
                proxies = {
                    'http': 'http://{}@{}:{}/'.format(proxy_auth, proxy_host, proxy_port),
                    'https': 'https://{}@{}:{}/'.format(proxy_auth, proxy_host, proxy_port)
                }
                r = requests.get('https://account.protonvpn.com/signup',
                                 proxies=proxies, timeout=4)
                if r.status_code != 200:
                    raise ConnectionError
                options = Options()
                options.add_argument('--proxy-server={}'.format(proxy))
                driver = webdriver.Chrome(
                    executable_path= driver_path, options=options)
                driver.set_page_load_timeout(40)
                try:
                    driver.get('https://account.protonvpn.com/signup')
                    WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                        (By.CSS_SELECTOR, 'a[class="pm-button"]')))
                except:
                    driver.close()
                    raise ConnectionError
                driver.close()
                proxy_on = True
            except:
                print('\033[31m' + "Proxy Connection error!" + '\033[0m')
                proxy_no += 1
                time.sleep(1)
                sys.stdout.write("\033[F")
                sys.stdout.write("\033[K")
                sys.stdout.write("\033[F")
                sys.stdout.write("\033[K")

    # ##################
    # Generate account
    # ##################

    try:
        options = Options()
        if use_proxy == True:
            options.add_argument('--proxy-server={}'.format(proxy))
        driver = webdriver.Chrome(
            executable_path= driver_path, options=options)

        driver.get('https://account.protonvpn.com/signup')

        button_free = WebDriverWait(driver, 60).until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, 'button[class="pm-button w100 mtauto pm-button--primaryborder"]')))
        button_free.click()

        def randomStringDigits(stringLength=13):
            # Generate a random string of letters and digits
            lettersAndDigits = string.ascii_letters + string.digits
            return ''.join(random.choice(lettersAndDigits) for i in range(stringLength))

        rngusername = randomStringDigits(9)
        rngpassword = randomStringDigits(15)

        username = WebDriverWait(driver, 60).until(EC.presence_of_element_located(
            (By.ID, 'username')))
        username.send_keys(rngusername)

        password = WebDriverWait(driver, 60).until(EC.presence_of_element_located(
            (By.ID, 'password')))
        password.send_keys(rngpassword)

        password_conf = WebDriverWait(driver, 60).until(EC.presence_of_element_located(
            (By.ID, 'passwordConfirmation')))
        password_conf.send_keys(rngpassword)

        input_email = WebDriverWait(driver, 60).until(EC.presence_of_element_located(
            (By.ID, 'email')))
        input_email.send_keys(email)

        submit = WebDriverWait(driver, 60).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[type="submit"]')))
        submit.click()

        # Solution for username already in use
        check_username_error = True
        while check_username_error == True:
            try:
                WebDriverWait(driver, 4).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, 'div[class="pt0-5 mb1"]')))
                check_username_error = False
            except:
                print("\nUsername error detected\n")
                rngusername = randomStringDigits(9)
                while username.get_attribute('value') != '':
                    username.send_keys(Keys.BACKSPACE)
                username.send_keys(rngusername)
                submit.click()
                check_username_error = True

        send = WebDriverWait(driver, 60).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[class="pm-button pm-button--primary"]')))
        send.click()

        try:

            account_details = [rngusername, rngpassword, email]
            time.sleep(.5)

            print("Username:\t", rngusername, "\n")
            print("Password:\t", rngpassword, "\n")
            print("Email:\t", email, "\n")

            with open('accounts.csv', 'a') as file:
                writer = csv.writer(file)
                writer.writerow(account_details)
            file.close()
            time.sleep(.5)

        except BaseException as E:
            print(E)
            input("\nPaused\n")

        print("\nYour account details have been saved in accounts.csv file, enter the code from temp mail into protonvpn site and you are done.\n")

        print(
            f'{bcolors.WARNING}[WARNING]\tTHIS WILL CLOSE ALL BROWSER TABS\n{bcolors.ENDC}')
        print(
            f'{bcolors.WARNING}[WARNING]\tPLEASE INPUT EMAIL CODE BEFORE PRESSING ANY BUTTON\n{bcolors.ENDC}')

        input("\nPress any key to exit! \n")

    except BaseException as E:
        print(E)
        input("\nPaused\n")
        print("\n\nThere was an error while creating account, restarting process in 3 seconds\n\n")
        time.sleep(3)
        proxy_no += 1
        try:
            driver.close()
        except:
            print('')
        create_account()

    except:
        print("\n\nThere was an error while creating account, restarting process in 3 seconds\n\n")
        time.sleep(3)
        proxy_no += 1
        try:
            driver.close()
        except:
            print('')
        create_account()


create_proxies()
